from tkinter import *
import pygame
import random

root = Tk()
root.title('Register Key')
root.geometry("550x309")
width = 550
height = 309
screen_width = root.winfo_screenwidth()
screen_height = root.winfo_screenheight()
x = (screen_width / 2) - (width / 2)
y = (screen_height / 2) - (height / 2)
root.geometry('%dx%d+%d+%d' % (width, height, x, y))


def generate():
    key_label.delete(0, END)
    key = ''
    section = ''
    flag = 1
    alphabet = '1234567890'
    alphabet2 = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ123456789'
    alphabet3 = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ'
    while len(key) < 20:
        if flag == 1:
            char = random.choice(alphabet2)
        else:
            char = random.choice(alphabet3)
        if char in alphabet:
            flag = 0
        if len(section) == 3 and flag == 1:
            key += random.choice(alphabet)
            section += random.choice(alphabet)
        else:
            key += char
            section += char
        if len(section) == 4:
            key += '-'
            section = ''
            flag = 1
    key = key[:-1]
    key_label.insert(0, key)


def play():
    pygame.mixer.music.load("undertale_037. Pathetic House.mp3")
    pygame.mixer.music.play(loops=999)


bg = PhotoImage(file="dead.png")
pygame.mixer.init()
my_label = Label(root, image=bg)
my_label.place(x=0, y=0, relwidth=1, relheight=1)
generate_button = Button(root, text="Сгенерировать ключ", command=generate, bg="black", fg="white", font=("Fixedsys", 20))
generate_button.pack(pady=100)

key_label = Entry(root, bd=0, width=20, font=("Fixedsys", 24))
key_label.pack(pady=10)

play()

root.mainloop()
